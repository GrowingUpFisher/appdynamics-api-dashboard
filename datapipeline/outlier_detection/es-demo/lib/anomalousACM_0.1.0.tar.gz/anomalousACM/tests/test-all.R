library(testthat)
library(anomalousACM)

test_package("anomalousACM")
